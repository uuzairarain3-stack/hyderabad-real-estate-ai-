const express = require('express');
const router = express.Router();
const { getDb, queryAll, queryOne } = require('../config/db');

router.get('/', async (req, res) => {
  try {
    const db = await getDb();
    const societies = queryAll(db, 'SELECT * FROM societies ORDER BY featured DESC, name ASC');
    res.json(societies);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const db = await getDb();
    const society = queryOne(db, 'SELECT * FROM societies WHERE id = ?', [req.params.id]);
    if (!society) return res.status(404).json({ error: 'Not found' });

    const brokers = queryAll(db, `
      SELECT b.*, sb.is_primary FROM brokers b
      JOIN society_brokers sb ON sb.broker_id = b.id
      WHERE sb.society_id = ?
      ORDER BY sb.is_primary DESC, b.rating DESC
    `, [req.params.id]);

    const listings = queryAll(db, `
      SELECT l.*, b.name as broker_name, b.phone as broker_phone
      FROM listings l
      LEFT JOIN brokers b ON b.id = l.broker_id
      WHERE l.society_id = ? AND l.status = 'active'
      ORDER BY l.created_at DESC
    `, [req.params.id]);

    res.json({ ...society, brokers, listings });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
