// Update broker color_tags to blue theme in live DB
const { getDb, initDb, saveDb } = require('./db');

async function fix() {
  await initDb();
  const db = await getDb();
  db.run("UPDATE brokers SET color_tag = '#4f8ef7' WHERE tier = 'vip'");
  db.run("UPDATE brokers SET color_tag = '#38d9c0' WHERE tier = 'premium'");
  db.run("UPDATE brokers SET color_tag = '#9b72f5' WHERE tier = 'standard'");
  saveDb(db);
  console.log('  ✓ Broker color tags updated to blue theme');
}
fix().catch(console.error);
